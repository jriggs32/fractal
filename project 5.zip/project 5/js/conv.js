//converts radians to degrees
function degToRad(deg) {
    return deg * (Math.PI / 180) - Math.PI / 2;
}


//random number generator
function randNum(min, max) { // min and max included 
    return (Math.random() * (max - min) + min)
}

function randCol() {

    return 'rgb(' +
        Math.floor(randNum(0, 255)) +
        ',' +
        Math.floor(randNum(0, 255)) +
        ',' +
        Math.floor(randNum(0, 255)) +
        ')';
}
